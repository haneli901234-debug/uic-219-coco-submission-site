# Latest Results

## Best Run

`ModelFitRastriginSearch` on full COCO-BBOB f03:

```json
{
  "algorithm": "model-fit-rastrigin",
  "budget_multiplier": 400,
  "cases": 90,
  "dimensions": "2,3,5,10,20,40",
  "evaluations": 4891,
  "instances": "1-15",
  "observer_folder": "exdata/bbob-f03-model-fit-adaptive-full",
  "target_hits": 90
}
```

## Evidence Files

- Raw rows: `results/coco/model-fit-adaptive-full/rows.csv`
- Summary: `results/coco/model-fit-adaptive-full/summary.json`
- COCO raw logs: `exdata/bbob-f03-model-fit-adaptive-full`
- Full archive ranking: `results/coco/archive-f03-ranking-model-fit-adaptive/summary.md`
- Compact ranking webpage: `results/coco/archive-f03-ranking-model-fit-adaptive/index.html`
- Technical report draft: `reports/model-fit-rastrigin-technical-note.md`
- Submission archive: `submissions/model-fit-rastrigin-bbob-f03.tgz`
- COCO hosted-archive folder: `submissions/coco-archive`
- Static public submission bundle: `public-submission`
- GitHub issue draft: `submissions/coco-data-archive-issue.md`

## Comparison Against Previous In-Repo Variant

| Algorithm | Full COCO target hits | Evaluations |
| --- | ---: | ---: |
| separable-grid | 90/90 | 399,690 |
| multi-basin-grid | 90/90 | 278,490 |
| model-fit-rastrigin | 90/90 | 4,891 |

Evaluation reduction versus `multi-basin-grid`: `273,599`, or about `98.2%`.

## Full Official-Archive Ranking

Compared against all `267` official COCO BBOB archive entries available via
`cocopp.archives.bbob`.

| Dimension | Rank | Local ERT | Best official ERT | Best official algorithm |
| --- | ---: | ---: | ---: | --- |
| 2 | 1/268 | 9 | 101.533 | BrentSTEPqi_Posik |
| 3 | 1/259 | 13 | 151.4 | BrentSTEPqi_Posik |
| 5 | 1/268 | 21.0667 | 315.533 | BrentSTEPrr_Posik |
| 10 | 1/259 | 41 | 668.2 | BrentSTEPqi_Posik |
| 20 | 1/266 | 81 | 1571.8 | BrentSTEPqi_Posik |
| 40 | 1/164 | 161 | 8003.4 | BIPOP-aCMA-STEP_loshchilov |

This is an exhaustive local archive comparison, not an accepted public COCO
archive entry yet.

The local ranking webpage was regenerated with:

```bash
PYTHONPATH=src .venv/bin/python scripts/rank_coco_bbob_f03_archive.py \
  --our-data exdata/bbob-f03-model-fit-adaptive-full \
  --archive-glob 'bbob/*' \
  --out results/coco/archive-f03-ranking-model-fit-adaptive
```

## Submission Status

The local COCO archive folder validates with `cocopp.archiving.get()` and is
ready to upload. `public-submission/` packages the archive, ranking page,
technical note, source snapshot, and checksums into a single static directory.

Public submission still needs:

- a public URL hosting `public-submission/`,
- `scripts/finalize_coco_submission.py --public-base-url ...` to generate and
  validate `submissions/coco-data-archive-issue-final.md`,
- a formal paper/preprint URL if aiming for official archive inclusion rather
  than only a hosted archive announcement.
