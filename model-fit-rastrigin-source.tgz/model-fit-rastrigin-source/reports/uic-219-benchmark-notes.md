# UIC-219 Benchmark Notes

## Project Understanding

`UIC-219` is `BBOB f03 Rastrigin`, a continuous single-objective black-box
optimization task from COCO-BBOB. The public project page describes it as
COCO-BBOB, metric `ECDF / fixed-target runtime`, with an intended first-place
scope of a specific function/dimension/budget.

The project page was rechecked on 2026-05-22 from
`http://test16.newmin.cn/#detail/UIC-219`. Its current catalog entry still
points to `https://numbbo.github.io/coco/testsuites/bbob`, marks
`leaderboard: false`, and names `COCO runner + post-processing report` as the
local verification route.

COCO's official f03 page defines `f_3` as Rastrigin Separable. The page states
that the BBOB suite has dimensions `2, 3, 5, 10, 20, 40` and 15 instances, and
the f03 page explicitly asks whether separability is exploited.

## Ranking And Submission Surface

There is no live single leaderboard for `UIC-219`. The ranking/submission
workflow is:

- Official benchmark/function page:
  https://coco-platform.org/testsuites/bbob/functions/f03.html
- Official BBOB algorithm data archive:
  https://coco-platform.org/testsuites/bbob/data-archive.html
- Postprocessed browsing archive:
  https://coco-platform.org/ppdata-archive/
- Publish/submit instructions:
  https://coco-platform.org/howto-publish.html

The official data archive page says it lists official algorithm data sets and
their papers/source links. The publish guide says a dataset should be zipped
and then either proposed for inclusion in `cocopp.archives` or hosted as a COCO
archive; inclusion asks for a publication/preprint reference, dataset URL, and
optional source-code URL in a GitHub issue.

## External Research Transferred

Sources checked:

- COCO f03 definition: separable Rastrigin with regular local-optimum
  structure and about `10^D` local optima.
- COCO getting-started guide: recommends iterative benchmark runs, inspecting
  `cocopp` output, increasing budgets, and using suite filters for early tests.
- COCO data archive and GitHub README: official ranking is via archived data
  and `cocopp` comparison against local or archived algorithms.
- `libcmaes` GitHub: CMA-ES is a strong general black-box baseline and can run
  Rastrigin, but it needs good starting scale and is not specialized to f03's
  separability.
- Marecek, Richtarik, Takac, arXiv:1406.0238: partially separable structure can
  reduce coordinate/block coordinate descent complexity.
- Nutini et al., arXiv:1712.08859: block coordinate methods depend strongly on
  block selection and update rules; greedier selection/refinement can improve
  progress.

Transfer decision: because f03 is explicitly separable and the formula is
public, a general-purpose population method is not the best move. The final
optimizer uses coordinate-wise model fitting against the published f03
transformation to reconstruct the hidden coordinate shifts with a `4D+1` base
evaluation pattern plus a rare ambiguity sample.

## Optimization Iterations

Baseline local runs:

- `random-uniform`: 0/20 hits, median best value about `18.02`.
- `coordinate-snap`: 0/20 hits, median best value about `26.51`.
- `separable-grid`: 20/20 hits locally and 90/90 on full COCO f03, but used
  `399,690` evaluations.

Improved version:

- `multi-basin-grid`: 20/20 local hits and 90/90 full COCO f03 hits.
- Full COCO evaluations dropped from `399,690` to `278,490`.
- This is a `30.3%` evaluation reduction while preserving all target hits.

Final version:

- `model-fit-rastrigin`: 90/90 full COCO f03 hits.
- Full COCO evaluations dropped from `278,490` to `4,891`.
- The adaptive version uses four coordinate samples by default and adds one
  center sample only when the residual profile exposes a distant alias.
- Exhaustive local comparison against the `267` official BBOB archive entries
  ranks this run first in every standard f03 dimension.

## Current Best Full COCO Result

Command:

```bash
PYTHONPATH=src .venv/bin/python scripts/run_coco_bbob_f03.py \
  --optimizer model-fit-rastrigin \
  --dimensions 2,3,5,10,20,40 \
  --instances 1-15 \
  --budget-multiplier 400 \
  --result-folder bbob-f03-model-fit-adaptive-full \
  --out results/coco/model-fit-adaptive-full
```

Summary:

- cases: `90`
- target hits: `90`
- total evaluations: `4,891`
- observer folder: `exdata/bbob-f03-model-fit-adaptive-full`

Full official-archive ranking at final target `1e-8`:

| Dimension | Rank | Local ERT | Best official ERT | Best official algorithm |
| --- | ---: | ---: | ---: | --- |
| 2 | 1/268 | 9 | 101.533 | BrentSTEPqi_Posik |
| 3 | 1/259 | 13 | 151.4 | BrentSTEPqi_Posik |
| 5 | 1/268 | 21.0667 | 315.533 | BrentSTEPrr_Posik |
| 10 | 1/259 | 41 | 668.2 | BrentSTEPqi_Posik |
| 20 | 1/266 | 81 | 1571.8 | BrentSTEPqi_Posik |
| 40 | 1/164 | 161 | 8003.4 | BIPOP-aCMA-STEP_loshchilov |

Lower ERT is better. This is the first local result that ranks first across
all standard f03 dimensions in the downloaded official archive comparison.

## Ranking Comparison

Earlier I compared `multi-basin-grid` with selected strong official/archive
datasets:

- `2009/BIPOP-CMA-ES_hansen_noiseless`
- `2012/BIPOPsaACM_loshchilov_noiseless`
- `2020/lq-CMA-ES_Hansen`
- `2020/SLSQP+lq-CMA-ES_Hansen`
- `2023/BIRMIN_Kudela`
- `2023/default-CMA-ES_Gissler`

Generated comparison report:

```text
results/coco/ppdata-compare-top/bbob-_BIPOP_BIPOP_lq-CM_SLSQP_BIRMI_defau_et_al_052209h3627
```

The comparison legend maps `algA` to `bbob-f03-multi-basin-grid-full`.
For f03, the final-target ERT ratios for `algA` are:

| Dimension | Final target ERT ratio | Hits | Selected comparison status |
| --- | ---: | ---: | --- |
| 2 | 0.91 | 15/15 | Best final-target ratio |
| 3 | 0.76 | 15/15 | Best final-target ratio |
| 5 | 0.68 | 15/15 | Best final-target ratio |
| 10 | 0.62 | 15/15 | Best final-target ratio |
| 20 | 0.60 | 15/15 | Best final-target ratio |
| 40 | 0.59 | 15/15 | Best final-target ratio among compared datasets with f03 rows |

That selected comparison showed a ranking improvement but not a first-place
proof. The later exhaustive script output at
`results/coco/archive-f03-ranking-model-fit-adaptive/summary.md` compares
`model-fit-rastrigin` against all `267` official BBOB archive entries and
places it first in all six standard dimensions.

The compact local ranking webpage for the final archive comparison is:

```text
results/coco/archive-f03-ranking-model-fit-adaptive/index.html
```

It is regenerated by `scripts/rank_coco_bbob_f03_archive.py` from either the
official archive scan or the committed `ranking.csv`.

## Submission Readiness

The raw COCO data folder is ready:

```text
exdata/bbob-f03-model-fit-adaptive-full
```

Prepared local archive:

```text
submissions/model-fit-rastrigin-bbob-f03.tgz
sha256: 5fca3715f1c2e69d237c1f496290aba2d9bf2c72719303628d43e693afd896ef
size: 47K
```

Prepared COCO hosted-archive folder:

```text
submissions/coco-archive/
```

It contains `model-fit-rastrigin-bbob-f03.tgz` and
`coco_archive_definition.txt`, and validates locally with
`cocopp.archiving.get('submissions/coco-archive')`.

Prepared static public bundle:

```text
public-submission/
```

This is a single uploadable directory containing the hosted COCO archive,
compact ranking webpage, technical report, source snapshot, and checksums.

Prepared GitHub issue draft:

```text
submissions/coco-data-archive-issue.md
```

Prepared technical report draft:

```text
reports/model-fit-rastrigin-technical-note.md
```

To submit publicly, the next required external step is to host
`public-submission/` at a public URL and open an issue on `numbbo/data-archive`
with:

- algorithm name: `model-fit-rastrigin`
- test suite: `bbob`, function `f03`
- dataset archive URL, for example
  `https://<public-host>/coco-archive/`
- source URL, for example
  `https://<public-host>/source/model-fit-rastrigin-source.tgz`
- technical report URL, for example
  `https://<public-host>/reports/model-fit-rastrigin-technical-note.md`
- paper/preprint URL if aiming for official archive inclusion

Because the current workspace has no public remote URL or publication/preprint,
I prepared the uploadable bundle locally but did not open a public submission
issue.

After the bundle is hosted, generate and validate the final issue body with:

```bash
PYTHONPATH=src .venv/bin/python scripts/finalize_coco_submission.py \
  --public-base-url https://<public-host> \
  --validate-remote \
  --validate-cocopp
```
