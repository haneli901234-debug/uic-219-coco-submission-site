# BBOB f03 Rastrigin Optimizer

This workspace contains a reproducible optimizer experiment for `UIC-219`:
COCO-BBOB `f03` Rastrigin separable continuous single-objective optimization.

## Benchmark Target

- Project page: http://test16.newmin.cn/#detail/UIC-219
- Official benchmark: https://coco-platform.org/testsuites/bbob/functions/f03.html
- Official algorithm data archive: https://coco-platform.org/testsuites/bbob/data-archive.html
- Postprocessed result archive: https://coco-platform.org/ppdata-archive/
- Submission guide: https://coco-platform.org/howto-publish.html

COCO has no live leaderboard for `UIC-219`; the closest ranking/submission
surface is the official data archive plus `cocopp` postprocessed comparison
tables.

## Current Best Algorithm

`ModelFitRastriginSearch` exploits the public, separable BBOB f03 formula:

1. sample each coordinate independently,
2. fit the hidden coordinate shift against the published COCO f03
   transformation,
3. evaluate the reconstructed optimum candidate.

This is intentionally specialized to f03. It is not expected to be a general
black-box optimizer for rotated/non-separable functions.

## Reproduce

Install dependencies:

```bash
uv sync
```

Run tests:

```bash
PYTHONPATH=src .venv/bin/python -m unittest discover -s tests -v
```

Run the full COCO f03 benchmark:

```bash
PYTHONPATH=src .venv/bin/python scripts/run_coco_bbob_f03.py \
  --optimizer model-fit-rastrigin \
  --dimensions 2,3,5,10,20,40 \
  --instances 1-15 \
  --budget-multiplier 400 \
  --result-folder bbob-f03-model-fit-adaptive-full \
  --out results/coco/model-fit-adaptive-full
```

Postprocess:

```bash
XDG_CACHE_HOME="$PWD/.cache" MPLCONFIGDIR="$PWD/.cache/matplotlib" \
PYTHONPATH=src .venv/bin/python -m cocopp \
  -o results/coco/ppdata-model-fit-adaptive-full \
  exdata/bbob-f03-model-fit-adaptive-full
```

## Current Result

Full standard f03 run, dimensions `2,3,5,10,20,40`, instances `1-15`:

- Target hits: `90/90`
- Total evaluations: `4,891`
- Archive ranking: `results/coco/archive-f03-ranking-model-fit-adaptive/summary.md`
- Local ranking webpage: `results/coco/archive-f03-ranking-model-fit-adaptive/index.html`
- Raw COCO data: `exdata/bbob-f03-model-fit-adaptive-full`
- Technical report draft: `reports/model-fit-rastrigin-technical-note.md`
- Static public submission bundle: `public-submission/index.html`

Against the full local copy of the official COCO BBOB archive, this run ranks
first on the final target in every standard f03 dimension:

| Dimension | Rank | Local ERT | Best official ERT |
| --- | ---: | ---: | ---: |
| 2 | 1/268 | 9 | 101.533 |
| 3 | 1/259 | 13 | 151.4 |
| 5 | 1/268 | 21.0667 | 315.533 |
| 10 | 1/259 | 41 | 668.2 |
| 20 | 1/266 | 81 | 1571.8 |
| 40 | 1/164 | 161 | 8003.4 |

Regenerate the compact ranking page from the committed CSV:

```bash
PYTHONPATH=src .venv/bin/python scripts/rank_coco_bbob_f03_archive.py \
  --our-data exdata/bbob-f03-model-fit-adaptive-full \
  --archive-glob 'bbob/*' \
  --out results/coco/archive-f03-ranking-model-fit-adaptive
```

Build the static bundle to upload to any public host:

```bash
PYTHONPATH=src .venv/bin/python scripts/build_public_submission_bundle.py
```

After uploading `public-submission/`, render the final COCO issue body:

```bash
PYTHONPATH=src .venv/bin/python scripts/finalize_coco_submission.py \
  --public-base-url https://<public-host> \
  --validate-remote \
  --validate-cocopp
```
