"""Render and optionally validate the public COCO data-archive issue body."""

from __future__ import annotations

import argparse
import hashlib
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_TEMPLATE = PROJECT_ROOT / "submissions" / "coco-data-archive-issue.md"
DEFAULT_OUT = PROJECT_ROOT / "submissions" / "coco-data-archive-issue-final.md"
PUBLIC_BUNDLE = PROJECT_ROOT / "public-submission"

REQUIRED_REMOTE_FILES = (
    "coco-archive/model-fit-rastrigin-bbob-f03.tgz",
    "coco-archive/coco_archive_definition.txt",
)

REMOTE_CONTENT_CHECKS = {
    "ranking/": b"1/268",
    "reports/model-fit-rastrigin-technical-note.md": b"model-fit-rastrigin",
    "source/model-fit-rastrigin-source.tgz": b"",
}


def normalize_base_url(url: str) -> str:
    parsed = urllib.parse.urlparse(url.strip())
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("public base URL must start with http:// or https:// and include a host")
    path = parsed.path.rstrip("/")
    normalized = parsed._replace(path=path, params="", query="", fragment="")
    return urllib.parse.urlunparse(normalized)


def join_url(base_url: str, relative: str) -> str:
    return f"{base_url.rstrip('/')}/{relative.lstrip('/')}"


def render_issue(template: str, base_url: str) -> str:
    rendered = template.replace("https://<public-host>", base_url.rstrip("/"))
    if "<public-host>" in rendered or "<public-source-repo-url>" in rendered:
        raise ValueError("unresolved public URL placeholder remains in rendered issue")
    return rendered


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def expected_digests(bundle_dir: Path) -> dict[str, str]:
    digests: dict[str, str] = {}
    for relative in REQUIRED_REMOTE_FILES:
        path = bundle_dir / relative
        if path.exists():
            digests[relative] = sha256_file(path)
    return digests


def validate_local_bundle(bundle_dir: Path) -> list[str]:
    errors: list[str] = []
    checksum_path = bundle_dir / "checksums.sha256"
    if not checksum_path.exists():
        return [f"missing {checksum_path}"]

    for line in checksum_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        match = re.match(r"^([0-9a-f]{64})  (.+)$", line)
        if not match:
            errors.append(f"bad checksum line: {line}")
            continue
        expected, relative = match.groups()
        path = bundle_dir / relative
        if not path.exists():
            errors.append(f"missing bundled file: {relative}")
            continue
        actual = sha256_file(path)
        if actual != expected:
            errors.append(f"checksum mismatch for {relative}: {actual} != {expected}")

    required_digests = expected_digests(bundle_dir)
    for relative in REQUIRED_REMOTE_FILES:
        path = bundle_dir / relative
        if not path.exists():
            errors.append(f"missing required file: {relative}")
            continue
        expected = required_digests[relative]
        actual = sha256_file(path)
        if actual != expected:
            errors.append(f"unexpected digest for {relative}: {actual} != {expected}")

    return errors


def fetch_url(url: str, timeout: float) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "uic219-coco-submission-validator/1.0"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read()


def validate_remote_bundle(base_url: str, timeout: float) -> list[str]:
    errors: list[str] = []
    digests = expected_digests(PUBLIC_BUNDLE)
    missing = [relative for relative in REQUIRED_REMOTE_FILES if relative not in digests]
    if missing:
        return [f"missing local required file for remote validation: {relative}" for relative in missing]

    for relative, expected in digests.items():
        url = join_url(base_url, relative)
        try:
            data = fetch_url(url, timeout)
        except (urllib.error.URLError, TimeoutError) as exc:
            errors.append(f"cannot fetch {url}: {exc}")
            continue
        actual = sha256_bytes(data)
        if actual != expected:
            errors.append(f"remote checksum mismatch for {relative}: {actual} != {expected}")

    for relative, needle in REMOTE_CONTENT_CHECKS.items():
        url = join_url(base_url, relative)
        try:
            data = fetch_url(url, timeout)
        except (urllib.error.URLError, TimeoutError) as exc:
            errors.append(f"cannot fetch {url}: {exc}")
            continue
        if needle and needle not in data:
            errors.append(f"remote content check failed for {relative}: missing {needle!r}")

    return errors


def validate_cocopp_archive(base_url: str) -> list[str]:
    try:
        import cocopp
    except ImportError as exc:
        return [f"cannot import cocopp: {exc}"]

    archive_url = join_url(base_url, "coco-archive")
    try:
        archive = cocopp.archiving.get(archive_url)
        entries = list(archive)
    except Exception as exc:  # cocopp can raise parser, network, and archive errors
        return [f"cocopp cannot read {archive_url}: {exc}"]

    expected = "model-fit-rastrigin-bbob-f03.tgz"
    if expected not in entries:
        return [f"cocopp archive is missing {expected}: {entries}"]
    return []


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--public-base-url", required=True, help="Published URL of public-submission/")
    parser.add_argument("--template", type=Path, default=DEFAULT_TEMPLATE)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--validate-local", action="store_true", default=True)
    parser.add_argument("--no-validate-local", action="store_false", dest="validate_local")
    parser.add_argument("--validate-remote", action="store_true")
    parser.add_argument("--validate-cocopp", action="store_true")
    parser.add_argument("--timeout", type=float, default=20.0)
    return parser.parse_args()


def display_path(path: Path) -> str:
    try:
        return str(path.relative_to(PROJECT_ROOT))
    except ValueError:
        return str(path)


def main() -> int:
    args = parse_args()
    base_url = normalize_base_url(args.public_base_url)
    template = args.template.read_text(encoding="utf-8")
    rendered = render_issue(template, base_url)

    errors: list[str] = []
    if args.validate_local:
        errors.extend(validate_local_bundle(PUBLIC_BUNDLE))
    if args.validate_remote:
        errors.extend(validate_remote_bundle(base_url, args.timeout))
    if args.validate_cocopp:
        errors.extend(validate_cocopp_archive(base_url))

    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(rendered, encoding="utf-8")
    print(f"wrote {display_path(args.out)}")
    print(f"archive URL: {join_url(base_url, 'coco-archive/')}")
    print(f"ranking URL: {join_url(base_url, 'ranking/')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
