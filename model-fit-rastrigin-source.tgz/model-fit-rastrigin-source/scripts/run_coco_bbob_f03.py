#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from bbob_f03.optimizers import BrentBasinSearch, ModelFitRastriginSearch, MultiBasinGridSearch, run_optimizer


def build_optimizer(name: str, *, model_fit_sample_points: int, model_fit_shift_grid_points: int):
    if name == "multi-basin-grid":
        return MultiBasinGridSearch()
    if name == "brent-basin":
        return BrentBasinSearch(coarse_points=33, basins=4, brent_iterations=22)
    if name == "model-fit-rastrigin":
        return ModelFitRastriginSearch(
            sample_points=model_fit_sample_points,
            shift_grid_points=model_fit_shift_grid_points,
        )
    raise ValueError(f"unknown optimizer: {name}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run CoordinateSnapSearch on official COCO-BBOB f03.")
    parser.add_argument("--dimensions", default="2,3,5,10", help="Comma-separated dimensions.")
    parser.add_argument("--instances", default="1,2,3,4,5", help="Comma-separated COCO instance indices.")
    parser.add_argument("--budget-multiplier", type=int, default=400, help="Evaluations per dimension.")
    parser.add_argument("--result-folder", default="bbob-f03-multi-basin-grid", help="COCO observer result folder.")
    parser.add_argument("--out", default="results/coco/latest", help="JSON/CSV summary output directory.")
    parser.add_argument("--model-fit-sample-points", type=int, default=4)
    parser.add_argument("--model-fit-shift-grid-points", type=int, default=2001)
    parser.add_argument(
        "--optimizer",
        default="multi-basin-grid",
        choices=["multi-basin-grid", "brent-basin", "model-fit-rastrigin"],
    )
    return parser.parse_args()


def main() -> None:
    try:
        import cocoex
    except ImportError as exc:
        raise SystemExit(
            "cocoex is not installed. Install with: python -m pip install coco-experiment cocopp"
        ) from exc

    args = parse_args()
    suite = cocoex.Suite(
        "bbob",
        "",
        f"dimensions: {args.dimensions} function_indices: 3 instance_indices: {args.instances}",
    )
    observer = cocoex.Observer("bbob", f"result_folder: {args.result_folder}")
    optimizer = build_optimizer(
        args.optimizer,
        model_fit_sample_points=args.model_fit_sample_points,
        model_fit_shift_grid_points=args.model_fit_shift_grid_points,
    )
    rows = []

    for problem in suite:
        try:
            problem.observe_with(observer)
            dimension = int(problem.dimension)
            budget = args.budget_multiplier * dimension

            class CocoObjective:
                evaluations = 0

                def __call__(self, x):
                    self.evaluations += 1
                    return float(problem(np.asarray(x, dtype=float)))

            result = run_optimizer(optimizer, CocoObjective(), dimension=dimension, budget=budget)
            problem.recommend(result.best_x)
            row = {
                "problem_id": problem.id,
                "dimension": dimension,
                "budget": budget,
                "evaluations": result.evaluations,
                "best_y": result.best_y,
                "target_hit": bool(problem.final_target_hit),
            }
            rows.append(row)
            print(json.dumps(row, ensure_ascii=False, sort_keys=True))
        finally:
            problem.free()

    summary = {
        "算法": optimizer.name,
        "用例数": len(rows),
        "目标命中数": sum(row["target_hit"] for row in rows),
        "总评估次数": sum(int(row["evaluations"]) for row in rows),
        "预算倍数": args.budget_multiplier,
        "维度": args.dimensions,
        "实例": args.instances,
        "COCO观察器目录": f"exdata/{args.result_folder}",
    }
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (out_dir / "rows.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    with (out_dir / "rows.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=sorted(rows[0]) if rows else [])
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
