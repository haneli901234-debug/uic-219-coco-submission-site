#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from bbob_f03.optimizers import CoordinateSnapSearch, MultiBasinGridSearch, RandomUniformSearch, SeparableGridSearch
from bbob_f03.runner import BenchmarkCase, aggregate_rows, run_local_cases


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run local BBOB f03-style shifted Rastrigin benchmarks.")
    parser.add_argument(
        "--algorithm",
        choices=["random", "coordinate-snap", "separable-grid", "multi-basin-grid"],
        default="multi-basin-grid",
    )
    parser.add_argument("--dimensions", default="2,3,5,10", help="Comma-separated dimensions.")
    parser.add_argument("--budget-multiplier", type=int, default=200, help="Evaluations per dimension.")
    parser.add_argument("--seeds", default="1,2,3,4,5", help="Comma-separated objective seeds.")
    parser.add_argument("--out", default="results/local/latest", help="Output directory.")
    return parser.parse_args()


def make_optimizer(name: str):
    if name == "random":
        return RandomUniformSearch(seed=17)
    if name == "separable-grid":
        return SeparableGridSearch()
    if name == "multi-basin-grid":
        return MultiBasinGridSearch()
    return CoordinateSnapSearch(seed=17, starts=6)


def main() -> None:
    args = parse_args()
    dimensions = [int(item) for item in args.dimensions.split(",") if item]
    seeds = [int(item) for item in args.seeds.split(",") if item]
    cases = [
        BenchmarkCase(dimension=dimension, budget=args.budget_multiplier * dimension, seed=seed)
        for dimension in dimensions
        for seed in seeds
    ]

    rows = run_local_cases(make_optimizer(args.algorithm), cases)
    summary = aggregate_rows(rows)

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (out_dir / "rows.json").write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    with (out_dir / "rows.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=sorted(rows[0]) if rows else [])
        writer.writeheader()
        writer.writerows(rows)

    print(json.dumps(summary, sort_keys=True))


if __name__ == "__main__":
    main()
