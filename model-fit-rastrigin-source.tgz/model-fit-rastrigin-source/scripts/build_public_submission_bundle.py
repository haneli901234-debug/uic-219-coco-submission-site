"""Build a static public submission bundle for UIC-219."""

from __future__ import annotations

import hashlib
import html
import gzip
import shutil
import tarfile
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUT = PROJECT_ROOT / "public-submission"

SOURCE_PATHS = (
    "README.md",
    "pyproject.toml",
    "uv.lock",
    "scripts",
    "src",
    "tests",
    "reports",
    "results/coco/archive-f03-ranking-model-fit-adaptive",
    "results/coco/model-fit-adaptive-full",
    "results/coco/uic-219-boss-report.html",
    "submissions/README.md",
    "submissions/coco-data-archive-issue.md",
)

REQUIRED_FILES = (
    "submissions/coco-archive/model-fit-rastrigin-bbob-f03.tgz",
    "submissions/coco-archive/coco_archive_definition.txt",
    "results/coco/archive-f03-ranking-model-fit-adaptive/index.html",
    "results/coco/archive-f03-ranking-model-fit-adaptive/ranking.csv",
    "results/coco/archive-f03-ranking-model-fit-adaptive/summary.md",
    "reports/model-fit-rastrigin-technical-note.md",
    "results/coco/uic-219-boss-report.html",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def require_inputs() -> None:
    missing = [relative for relative in REQUIRED_FILES if not (PROJECT_ROOT / relative).exists()]
    if missing:
        joined = "\n".join(f"- {item}" for item in missing)
        raise FileNotFoundError(f"missing required submission inputs:\n{joined}")


def reset_output(out_dir: Path) -> None:
    out_dir = out_dir.resolve()
    if out_dir.name != "public-submission" or PROJECT_ROOT.resolve() not in out_dir.parents:
        raise ValueError(f"refusing to overwrite unexpected output directory: {out_dir}")
    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True)


def copy_public_inputs(out_dir: Path) -> None:
    (out_dir / ".nojekyll").write_text("", encoding="utf-8")

    archive_dir = out_dir / "coco-archive"
    archive_dir.mkdir()
    for name in ("model-fit-rastrigin-bbob-f03.tgz", "coco_archive_definition.txt"):
        shutil.copy2(PROJECT_ROOT / "submissions" / "coco-archive" / name, archive_dir / name)

    ranking_dir = out_dir / "ranking"
    ranking_dir.mkdir()
    for name in ("index.html", "ranking.csv", "summary.md"):
        shutil.copy2(
            PROJECT_ROOT / "results" / "coco" / "archive-f03-ranking-model-fit-adaptive" / name,
            ranking_dir / name,
        )

    report_dir = out_dir / "reports"
    report_dir.mkdir()
    shutil.copy2(
        PROJECT_ROOT / "reports" / "model-fit-rastrigin-technical-note.md",
        report_dir / "model-fit-rastrigin-technical-note.md",
    )
    shutil.copy2(PROJECT_ROOT / "results" / "coco" / "uic-219-boss-report.html", report_dir / "boss-report.html")


def normalize_tarinfo(info: tarfile.TarInfo) -> tarfile.TarInfo | None:
    parts = Path(info.name).parts
    if any(part in {".cache", ".venv", "__pycache__"} for part in parts):
        return None
    if info.name.endswith((".pyc", ".pyo")):
        return None
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    return info


def build_source_archive(out_dir: Path) -> None:
    source_dir = out_dir / "source"
    source_dir.mkdir()
    with (source_dir / "model-fit-rastrigin-source.tgz").open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for relative in SOURCE_PATHS:
                    source = PROJECT_ROOT / relative
                    if source.exists():
                        archive.add(
                            source,
                            arcname=f"model-fit-rastrigin-source/{relative}",
                            filter=normalize_tarinfo,
                        )


def checksum_rows(out_dir: Path) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for path in sorted(item for item in out_dir.rglob("*") if item.is_file()):
        if path.name == "checksums.sha256":
            continue
        rows.append((path.relative_to(out_dir).as_posix(), sha256(path)))
    return rows


def write_checksums(out_dir: Path, rows: list[tuple[str, str]]) -> None:
    lines = [f"{digest}  {relative}" for relative, digest in rows]
    (out_dir / "checksums.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_readme(out_dir: Path, rows: list[tuple[str, str]]) -> None:
    data_digest = dict(rows)["coco-archive/model-fit-rastrigin-bbob-f03.tgz"]
    text = f"""# UIC-219 Public Submission Bundle

This directory is ready to host as static files for the UIC-219 COCO-BBOB f03
submission.

## Hosted URLs After Upload

- `https://<public-host>/coco-archive/`
- `https://<public-host>/coco-archive/coco_archive_definition.txt`
- `https://<public-host>/coco-archive/model-fit-rastrigin-bbob-f03.tgz`
- `https://<public-host>/ranking/`
- `https://<public-host>/reports/model-fit-rastrigin-technical-note.md`
- `https://<public-host>/reports/boss-report.html`
- `https://<public-host>/source/model-fit-rastrigin-source.tgz`
- `https://<public-host>/checksums.sha256`

## Main Data Checksum

```text
{data_digest}  coco-archive/model-fit-rastrigin-bbob-f03.tgz
```

After upload, replace the placeholders in
`../submissions/coco-data-archive-issue.md` with the public URLs above and open
an issue at `https://github.com/numbbo/data-archive/issues`.

The repository helper can render and validate the final issue body:

```bash
PYTHONPATH=src .venv/bin/python scripts/finalize_coco_submission.py \\
  --public-base-url https://<public-host> \\
  --validate-remote \\
  --validate-cocopp
```
"""
    (out_dir / "README.md").write_text(text, encoding="utf-8")


def write_index(out_dir: Path, rows: list[tuple[str, str]]) -> None:
    digest_by_path = dict(rows)
    summary = [
        ("COCO archive", "coco-archive/", "Hosted COCO archive folder"),
        ("Data tgz", "coco-archive/model-fit-rastrigin-bbob-f03.tgz", "Raw observer output for BBOB f03"),
        ("Archive definition", "coco-archive/coco_archive_definition.txt", "COCO archive manifest"),
        ("Ranking page", "ranking/", "Local comparison against official BBOB archive"),
        ("Technical note", "reports/model-fit-rastrigin-technical-note.md", "Method and reproducibility report"),
        ("Boss report", "reports/boss-report.html", "Chinese executive summary"),
        ("Source bundle", "source/model-fit-rastrigin-source.tgz", "Source snapshot for review"),
        ("Checksums", "checksums.sha256", "SHA-256 manifest"),
    ]
    cards = "\n".join(
        f"""
        <article>
          <h2>{html.escape(title)}</h2>
          <p>{html.escape(description)}</p>
          <a href="{html.escape(href)}">{html.escape(href)}</a>
          <code>{html.escape(digest_by_path.get(href, ""))}</code>
        </article>
        """
        for title, href, description in summary
    )
    document = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>UIC-219 COCO BBOB f03 Submission Bundle</title>
  <style>
    :root {{
      --bg: #f6f8fb;
      --panel: #ffffff;
      --ink: #16212f;
      --muted: #5f6c7a;
      --line: #dce4ec;
      --accent: #0b766f;
    }}
    body {{
      margin: 0;
      background: var(--bg);
      color: var(--ink);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      line-height: 1.5;
    }}
    main {{
      width: min(1080px, calc(100% - 32px));
      margin: 0 auto;
      padding: 40px 0;
    }}
    header {{
      margin-bottom: 24px;
    }}
    h1 {{
      margin: 0 0 10px;
      letter-spacing: 0;
    }}
    header p, article p {{
      color: var(--muted);
      margin: 0 0 12px;
    }}
    .grid {{
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      gap: 16px;
    }}
    article {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 18px;
    }}
    article h2 {{
      font-size: 18px;
      margin: 0 0 8px;
      letter-spacing: 0;
    }}
    a {{
      color: var(--accent);
      display: block;
      font-weight: 700;
      margin-bottom: 10px;
      overflow-wrap: anywhere;
    }}
    code {{
      display: block;
      color: var(--muted);
      font-size: 12px;
      overflow-wrap: anywhere;
    }}
  </style>
</head>
<body>
  <main>
    <header>
      <h1>UIC-219 COCO BBOB f03 Submission Bundle</h1>
      <p>
        Static hosting package for <code>model-fit-rastrigin</code>, including
        the COCO archive, rank-1 evidence page, technical note, source snapshot,
        and checksums.
      </p>
    </header>
    <section class="grid">
      {cards}
    </section>
  </main>
</body>
</html>
"""
    (out_dir / "index.html").write_text(
        "\n".join(line.rstrip() for line in document.splitlines()) + "\n",
        encoding="utf-8",
    )


def main() -> None:
    out_dir = DEFAULT_OUT
    require_inputs()
    reset_output(out_dir)
    copy_public_inputs(out_dir)
    build_source_archive(out_dir)
    rows = checksum_rows(out_dir)
    write_readme(out_dir, rows)
    rows = checksum_rows(out_dir)
    write_checksums(out_dir, rows)
    write_index(out_dir, rows)
    rows = checksum_rows(out_dir)
    write_checksums(out_dir, rows)
    print(f"built {out_dir.relative_to(PROJECT_ROOT)}")
    print(f"files: {len(rows)}")


if __name__ == "__main__":
    main()
