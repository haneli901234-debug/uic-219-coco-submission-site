"""Rank the local BBOB f03 run against COCO's official BBOB archive."""

from __future__ import annotations

import argparse
import csv
import fnmatch
import html
import math
import os
import time
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("XDG_CACHE_HOME", str(PROJECT_ROOT / ".cache"))
os.environ.setdefault("MPLCONFIGDIR", str(PROJECT_ROOT / ".cache" / "matplotlib"))

import cocopp  # noqa: E402
from cocopp import pproc  # noqa: E402


DEFAULT_DIMS = (2, 3, 5, 10, 20, 40)


@dataclass(frozen=True)
class RankRow:
    dimension: int
    rank: int
    algorithm: str
    source: str
    ert: float
    hits: int
    runs: int
    is_local: bool


def source_label(path: str) -> str:
    normalized = str(path).replace("\\", "/")
    marker = "/bbob/"
    if marker in normalized:
        return normalized.split(marker, 1)[1]
    return normalized


def success_count(ds: pproc.DataSet, target: float) -> int:
    successes = ds.detSuccesses([target], raw_values=True)
    return int(np.asarray(successes).ravel()[0])


def run_count(ds: pproc.DataSet) -> int:
    runs = ds.nbRuns() if callable(ds.nbRuns) else ds.nbRuns
    return int(runs)


def dsl_rows(
    dsl: Iterable[pproc.DataSet],
    *,
    source: str,
    target: float,
    local: bool,
) -> list[RankRow]:
    rows: list[RankRow] = []
    for ds in dsl:
        ert = float(ds.detERT([target])[0])
        rows.append(
            RankRow(
                dimension=int(ds.dim),
                rank=0,
                algorithm=str(ds.algId),
                source=source_label(source),
                ert=ert,
                hits=success_count(ds, target),
                runs=run_count(ds),
                is_local=local,
            )
        )
    return rows


def archive_rows(loaded: object, *, target: float) -> list[RankRow]:
    rows: list[RankRow] = []
    if not isinstance(loaded, dict):
        return dsl_rows(loaded, source="archive", target=target, local=False)

    for _dim, by_source in loaded.items():
        for source, dsl in by_source.items():
            rows.extend(dsl_rows(dsl, source=source, target=target, local=False))
    return rows


def archive_entries(pattern: str) -> list[str]:
    archive_prefix = "bbob/"
    normalized = pattern[len(archive_prefix) :] if pattern.startswith(archive_prefix) else pattern
    if any(char in normalized for char in "*?[]"):
        return [entry for entry in cocopp.archives.bbob if fnmatch.fnmatch(entry, normalized)]
    return [entry for entry in cocopp.archives.bbob if entry == normalized or normalized in entry]


def load_official_rows(
    pattern: str,
    *,
    function: int,
    target: float,
    retries: int,
    retry_wait: float,
) -> tuple[list[RankRow], list[str]]:
    rows: list[RankRow] = []
    failures: list[str] = []
    entries = archive_entries(pattern)
    for index, entry in enumerate(entries, start=1):
        print(f"[{index}/{len(entries)}] {entry}", flush=True)
        last_error: Exception | None = None
        for attempt in range(1, retries + 1):
            try:
                path = cocopp.archives.bbob.get(entry)
                dsl = cocopp.load2(
                    path,
                    keep=lambda ds: ds.funcId == function,
                    flat_list=True,
                )
                rows.extend(dsl_rows(dsl, source=path, target=target, local=False))
                break
            except Exception as exc:  # cocopp raises several network and parse errors
                last_error = exc
                if attempt < retries:
                    time.sleep(retry_wait)
        else:
            failures.append(f"{entry}: {last_error}")
            print(f"  failed: {last_error}", flush=True)
    return rows, failures


def local_rows(local_data: Path, *, function: int, target: float) -> list[RankRow]:
    dsl = cocopp.load2(
        str(local_data),
        keep=lambda ds: ds.funcId == function,
        flat_list=True,
    )
    return dsl_rows(dsl, source=str(local_data), target=target, local=True)


def assign_ranks(rows: list[RankRow], dims: Iterable[int]) -> list[RankRow]:
    ranked: list[RankRow] = []
    for dim in dims:
        dim_rows = [row for row in rows if row.dimension == dim]
        dim_rows.sort(key=lambda row: (math.isinf(row.ert), row.ert, row.algorithm, row.source))
        for index, row in enumerate(dim_rows, start=1):
            ranked.append(
                RankRow(
                    dimension=row.dimension,
                    rank=index,
                    algorithm=row.algorithm,
                    source=row.source,
                    ert=row.ert,
                    hits=row.hits,
                    runs=row.runs,
                    is_local=row.is_local,
                )
            )
    return ranked


def write_csv(path: Path, rows: list[RankRow]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            lineterminator="\n",
            fieldnames=[
                "dimension",
                "rank",
                "algorithm",
                "source",
                "ert",
                "hits",
                "runs",
                "is_local",
            ],
        )
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    "dimension": row.dimension,
                    "rank": row.rank,
                    "algorithm": row.algorithm,
                    "source": row.source,
                    "ert": "inf" if math.isinf(row.ert) else f"{row.ert:.12g}",
                    "hits": row.hits,
                    "runs": row.runs,
                    "is_local": row.is_local,
                }
            )


def format_ert(value: float, precision: int = 6) -> str:
    return "inf" if math.isinf(value) else f"{value:.{precision}g}"


def write_summary(
    path: Path,
    rows: list[RankRow],
    *,
    target: float,
    dims: Iterable[int],
    failures: list[str],
) -> None:
    local_by_dim = {row.dimension: row for row in rows if row.is_local}
    lines = [
        "# COCO BBOB f03 归档排名",
        "",
        f"目标精度：`{target:g}`",
        "",
        "| 维度 | 本地排名 | 条目数 | 本地算法 | 本地最佳 ERT | 官方最佳 ERT | 官方最佳算法 |",
        "| --- | ---: | ---: | --- | ---: | ---: | --- |",
    ]

    for dim in dims:
        dim_rows = [row for row in rows if row.dimension == dim]
        official_rows = [row for row in dim_rows if not row.is_local]
        best_official = official_rows[0] if official_rows else None
        local = local_by_dim.get(dim)
        if local is None:
            lines.append(f"| {dim} | 缺失 | {len(dim_rows)} | 缺失 | 缺失 | 缺失 | 缺失 |")
            continue
        best_ert = "缺失" if best_official is None else format_ert(best_official.ert)
        best_alg = "缺失" if best_official is None else best_official.algorithm
        local_ert = format_ert(local.ert)
        lines.append(
            f"| {dim} | {local.rank} | {len(dim_rows)} | {local.algorithm} | {local_ert} | {best_ert} | {best_alg} |"
        )

    lines.extend(["", "## 各维度前 5 名", ""])
    for dim in dims:
        lines.append(f"### {dim} 维")
        lines.append("")
        lines.append("| 排名 | 算法 | ERT | 命中 | 来源 |")
        lines.append("| ---: | --- | ---: | ---: | --- |")
        for row in [row for row in rows if row.dimension == dim][:5]:
            ert = format_ert(row.ert)
            marker = " 本地" if row.is_local else ""
            lines.append(
                f"| {row.rank} | {row.algorithm}{marker} | {ert} | {row.hits}/{row.runs} | `{row.source}` |"
            )
        lines.append("")

    if failures:
        lines.extend(["## 加载失败的归档条目", ""])
        for failure in failures:
            lines.append(f"- `{failure}`")
        lines.append("")

    path.write_text("\n".join(lines), encoding="utf-8")


def rows_from_csv(path: Path) -> list[RankRow]:
    rows: list[RankRow] = []
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for item in reader:
            raw_ert = item["ert"]
            rows.append(
                RankRow(
                    dimension=int(item["dimension"]),
                    rank=int(item["rank"]),
                    algorithm=item["algorithm"],
                    source=item["source"],
                    ert=math.inf if raw_ert == "inf" else float(raw_ert),
                    hits=int(item["hits"]),
                    runs=int(item["runs"]),
                    is_local=item["is_local"].lower() == "true",
                )
            )
    return rows


def write_html(
    path: Path,
    rows: list[RankRow],
    *,
    target: float,
    dims: Iterable[int],
    failures: list[str],
) -> None:
    local_by_dim = {row.dimension: row for row in rows if row.is_local}
    summary_rows: list[str] = []
    top_sections: list[str] = []

    for dim in dims:
        dim_rows = [row for row in rows if row.dimension == dim]
        official_rows = [row for row in dim_rows if not row.is_local]
        best_official = official_rows[0] if official_rows else None
        local = local_by_dim.get(dim)
        if local is None:
            summary_rows.append(
                f"<tr><td>{dim}</td><td>缺失</td><td>{len(dim_rows)}</td>"
                "<td>缺失</td><td>缺失</td><td>缺失</td><td>缺失</td></tr>"
            )
        else:
            best_ert = "缺失" if best_official is None else format_ert(best_official.ert)
            best_alg = "缺失" if best_official is None else best_official.algorithm
            summary_rows.append(
                "<tr>"
                f"<td>{dim}</td>"
                f"<td><strong>{local.rank}/{len(dim_rows)}</strong></td>"
                f"<td>{len(dim_rows)}</td>"
                f"<td>{html.escape(local.algorithm)}</td>"
                f"<td>{format_ert(local.ert)}</td>"
                f"<td>{html.escape(best_ert)}</td>"
                f"<td>{html.escape(best_alg)}</td>"
                "</tr>"
            )

        top_rows = []
        for row in dim_rows[:5]:
            row_class = " class=\"local-row\"" if row.is_local else ""
            local_badge = " <span>本地</span>" if row.is_local else ""
            top_rows.append(
                f"<tr{row_class}>"
                f"<td>{row.rank}</td>"
                f"<td>{html.escape(row.algorithm)}{local_badge}</td>"
                f"<td>{format_ert(row.ert)}</td>"
                f"<td>{row.hits}/{row.runs}</td>"
                f"<td><code>{html.escape(row.source)}</code></td>"
                "</tr>"
            )
        top_sections.append(
            f"""
            <section>
              <h2>{dim} 维前 5 名</h2>
              <table>
                <thead>
                  <tr><th>排名</th><th>算法</th><th>ERT</th><th>命中</th><th>来源</th></tr>
                </thead>
                <tbody>{''.join(top_rows)}</tbody>
              </table>
            </section>
            """
        )

    failures_block = ""
    if failures:
        items = "".join(f"<li><code>{html.escape(failure)}</code></li>" for failure in failures)
        failures_block = f"<section><h2>加载失败的归档条目</h2><ul>{items}</ul></section>"

    document = f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>COCO BBOB f03 归档排名</title>
  <style>
    :root {{
      color-scheme: light;
      --bg: #f7f9fb;
      --panel: #ffffff;
      --ink: #15202b;
      --muted: #5c6b7a;
      --line: #d9e1ea;
      --accent: #0b766f;
      --accent-soft: #e6f4f1;
    }}
    body {{
      margin: 0;
      background: var(--bg);
      color: var(--ink);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      line-height: 1.5;
    }}
    main {{
      width: min(1120px, calc(100% - 32px));
      margin: 0 auto;
      padding: 40px 0;
    }}
    header, section {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 24px;
      margin-bottom: 20px;
    }}
    h1, h2 {{
      margin: 0 0 12px;
      letter-spacing: 0;
    }}
    p {{
      margin: 0 0 12px;
      color: var(--muted);
    }}
    .badges {{
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 18px;
    }}
    .badges span, td span {{
      border-radius: 999px;
      background: var(--accent-soft);
      color: var(--accent);
      font-size: 12px;
      font-weight: 700;
      padding: 3px 8px;
      text-transform: none;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }}
    th, td {{
      border-bottom: 1px solid var(--line);
      padding: 10px 8px;
      text-align: left;
      vertical-align: top;
    }}
    th {{
      color: var(--muted);
      font-size: 12px;
      text-transform: none;
    }}
    code {{
      white-space: normal;
      overflow-wrap: anywhere;
    }}
    .local-row {{
      background: var(--accent-soft);
    }}
    a {{
      color: var(--accent);
    }}
  </style>
</head>
<body>
  <main>
    <header>
      <h1>COCO BBOB f03 归档排名</h1>
      <p>
        本地 <code>model-fit-rastrigin</code> 结果与
        <code>cocopp.archives.bbob</code> 中的 COCO BBOB f03 官方归档条目对比，
        目标精度为 <code>{target:g}</code>。ERT 越低越好；当前本地只有这一条候选结果，
        因此“本地最佳 ERT”就是这次本地算法的 ERT。
      </p>
      <div class="badges">
        <span>UIC-219</span>
        <span>COCO-BBOB f03</span>
        <span>完整归档对比</span>
      </div>
    </header>
    <section>
      <h2>汇总</h2>
      <table>
        <thead>
          <tr>
            <th>维度</th>
            <th>本地排名</th>
            <th>条目数</th>
            <th>本地算法</th>
            <th>本地最佳 ERT</th>
            <th>官方最佳 ERT</th>
            <th>官方最佳算法</th>
          </tr>
        </thead>
        <tbody>{''.join(summary_rows)}</tbody>
      </table>
    </section>
    {''.join(top_sections)}
    {failures_block}
  </main>
</body>
</html>
"""
    path.write_text(document, encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--our-data", type=Path, default=Path("exdata/bbob-f03-multi-basin-grid-full"))
    parser.add_argument("--from-csv", type=Path, help="Regenerate summary/html from an existing ranking.csv")
    parser.add_argument("--archive-glob", default="bbob/*")
    parser.add_argument("--function", type=int, default=3)
    parser.add_argument("--target", type=float, default=1e-8)
    parser.add_argument("--dimensions", default=",".join(str(dim) for dim in DEFAULT_DIMS))
    parser.add_argument("--out", type=Path, default=Path("results/coco/archive-f03-ranking"))
    parser.add_argument("--max-retries", type=int, default=3)
    parser.add_argument("--retry-wait", type=float, default=1.0)
    parser.add_argument("--show-warnings", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if not args.show_warnings:
        warnings.filterwarnings("ignore", category=UserWarning, module="cocopp")

    dims = tuple(int(dim) for dim in args.dimensions.split(",") if dim)
    args.out.mkdir(parents=True, exist_ok=True)

    failures: list[str] = []
    if args.from_csv:
        ranked = rows_from_csv(args.from_csv)
        write_csv(args.out / "ranking.csv", ranked)
    else:
        rows, failures = load_official_rows(
            args.archive_glob,
            function=args.function,
            target=args.target,
            retries=args.max_retries,
            retry_wait=args.retry_wait,
        )
        rows.extend(local_rows(args.our_data, function=args.function, target=args.target))
        ranked = assign_ranks(rows, dims)
        write_csv(args.out / "ranking.csv", ranked)

    write_summary(args.out / "summary.md", ranked, target=args.target, dims=dims, failures=failures)
    write_html(args.out / "index.html", ranked, target=args.target, dims=dims, failures=failures)
    if failures:
        (args.out / "failures.txt").write_text("\n".join(failures) + "\n", encoding="utf-8")

    for row in ranked:
        if row.is_local:
            ert = format_ert(row.ert)
            print(
                f"{row.dimension} 维排名 {row.rank} / "
                f"{sum(1 for candidate in ranked if candidate.dimension == row.dimension)} "
                f"ERT={ert} 命中={row.hits}/{row.runs}"
            )
    if failures:
        print(f"加载失败的归档条目数：{len(failures)}")


if __name__ == "__main__":
    main()
