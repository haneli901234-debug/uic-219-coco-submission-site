from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable

import numpy as np

from .functions import Rastrigin
from .optimizers import Optimizer, run_optimizer


@dataclass(frozen=True)
class BenchmarkCase:
    dimension: int
    budget: int
    seed: int


def deterministic_shift(dimension: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.uniform(-4.0, 4.0, size=dimension)


def run_local_cases(optimizer: Optimizer, cases: Iterable[BenchmarkCase]) -> list[dict]:
    rows = []
    for case in cases:
        objective = Rastrigin(shift=deterministic_shift(case.dimension, case.seed))
        result = run_optimizer(
            optimizer,
            objective=objective,
            dimension=case.dimension,
            budget=case.budget,
        )
        row = asdict(case)
        row.update(
            algorithm=result.algorithm,
            best_y=result.best_y,
            evaluations=result.evaluations,
        )
        rows.append(row)
    return rows


def aggregate_rows(rows: Iterable[dict], target: float = 1e-8) -> dict:
    materialized = list(rows)
    best_values = [float(row["best_y"]) for row in materialized]
    evaluations = [int(row["evaluations"]) for row in materialized]
    return {
        "cases": len(materialized),
        "target": float(target),
        "target_hits": sum(value <= target for value in best_values),
        "best_y_min": min(best_values) if best_values else float("nan"),
        "best_y_median": float(np.median(best_values)) if best_values else float("nan"),
        "best_y_mean": float(np.mean(best_values)) if best_values else float("nan"),
        "evaluations": sum(evaluations),
    }
