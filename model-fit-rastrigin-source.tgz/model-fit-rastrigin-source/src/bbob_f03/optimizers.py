from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import numpy as np


LOWER_BOUND = -5.0
UPPER_BOUND = 5.0


class Objective(Protocol):
    evaluations: int

    def __call__(self, x: np.ndarray) -> float:
        ...


@dataclass(frozen=True)
class OptimizationResult:
    algorithm: str
    best_x: np.ndarray
    best_y: float
    evaluations: int


class Optimizer(Protocol):
    name: str

    def optimize(self, objective: Objective, dimension: int, budget: int) -> OptimizationResult:
        ...


class BudgetedEvaluator:
    def __init__(self, objective: Objective, budget: int):
        self.objective = objective
        self.budget = int(budget)
        self.best_x: np.ndarray | None = None
        self.best_y = float("inf")
        self.used = 0

    @property
    def remaining(self) -> int:
        return self.budget - self.used

    def evaluate(self, x: np.ndarray) -> float:
        if self.remaining <= 0:
            raise RuntimeError("evaluation budget exhausted")
        clipped = np.clip(np.asarray(x, dtype=float), LOWER_BOUND, UPPER_BOUND)
        y = float(self.objective(clipped))
        self.used += 1
        if y < self.best_y:
            self.best_y = y
            self.best_x = clipped.copy()
        return y

    def result(self, algorithm: str, dimension: int) -> OptimizationResult:
        best_x = self.best_x if self.best_x is not None else np.zeros(dimension)
        return OptimizationResult(
            algorithm=algorithm,
            best_x=best_x,
            best_y=float(self.best_y),
            evaluations=self.used,
        )


@dataclass
class RandomUniformSearch:
    seed: int = 0
    name: str = "random-uniform"

    def optimize(self, objective: Objective, dimension: int, budget: int) -> OptimizationResult:
        evaluator = BudgetedEvaluator(objective, budget)
        rng = np.random.default_rng(self.seed)
        while evaluator.remaining:
            evaluator.evaluate(rng.uniform(LOWER_BOUND, UPPER_BOUND, size=dimension))
        return evaluator.result(self.name, dimension)


@dataclass
class CoordinateSnapSearch:
    seed: int = 0
    starts: int = 5
    name: str = "coordinate-snap"

    def optimize(self, objective: Objective, dimension: int, budget: int) -> OptimizationResult:
        evaluator = BudgetedEvaluator(objective, budget)
        rng = np.random.default_rng(self.seed)

        starts = [np.zeros(dimension)]
        starts.extend(rng.uniform(LOWER_BOUND, UPPER_BOUND, size=dimension) for _ in range(max(0, self.starts - 1)))
        grid = np.arange(int(LOWER_BOUND), int(UPPER_BOUND) + 1, dtype=float)

        for start in starts:
            if evaluator.remaining <= 0:
                break
            current = np.clip(start.copy(), LOWER_BOUND, UPPER_BOUND)
            evaluator.evaluate(current)
            improved = True
            while improved and evaluator.remaining > 0:
                improved = False
                for axis in range(dimension):
                    if evaluator.remaining <= 0:
                        break
                    axis_best_value = current[axis]
                    axis_best_score = evaluator.best_y
                    for value in grid:
                        if evaluator.remaining <= 0:
                            break
                        candidate = current.copy()
                        candidate[axis] = value
                        score = evaluator.evaluate(candidate)
                        if score < axis_best_score:
                            axis_best_score = score
                            axis_best_value = value
                            improved = True
                    current[axis] = axis_best_value
                if evaluator.best_x is not None:
                    current = evaluator.best_x.copy()

        return evaluator.result(self.name, dimension)


@dataclass
class SeparableGridSearch:
    coarse_points: int = 121
    refinement_points: int = 9
    refinements: int = 8
    name: str = "separable-grid"

    def optimize(self, objective: Objective, dimension: int, budget: int) -> OptimizationResult:
        evaluator = BudgetedEvaluator(objective, budget)
        current = np.zeros(dimension)
        evaluator.evaluate(current)

        for axis in range(dimension):
            if evaluator.remaining <= 0:
                break
            current = self._optimize_axis(evaluator, current, axis)
            if evaluator.best_x is not None:
                current = evaluator.best_x.copy()

        return evaluator.result(self.name, dimension)

    def _optimize_axis(self, evaluator: BudgetedEvaluator, current: np.ndarray, axis: int) -> np.ndarray:
        def evaluate_at(value: float) -> float:
            candidate = current.copy()
            candidate[axis] = value
            return evaluator.evaluate(candidate)

        best_value = float(current[axis])
        best_score = evaluator.best_y

        coarse_count = min(max(3, self.coarse_points), evaluator.remaining)
        coarse_values = np.linspace(LOWER_BOUND, UPPER_BOUND, coarse_count)
        for value in coarse_values:
            if evaluator.remaining <= 0:
                break
            score = evaluate_at(float(value))
            if score < best_score:
                best_score = score
                best_value = float(value)

        width = 10.0 / max(1, coarse_count - 1)
        for _ in range(self.refinements):
            if evaluator.remaining <= 0:
                break
            count = min(max(3, self.refinement_points), evaluator.remaining)
            low = max(LOWER_BOUND, best_value - width)
            high = min(UPPER_BOUND, best_value + width)
            values = np.linspace(low, high, count)
            for value in values:
                if evaluator.remaining <= 0:
                    break
                score = evaluate_at(float(value))
                if score < best_score:
                    best_score = score
                    best_value = float(value)
            width = max((high - low) / max(1, count - 1), 1e-12)

        updated = current.copy()
        updated[axis] = best_value
        return updated


@dataclass
class MultiBasinGridSearch:
    coarse_points: int = 61
    basins: int = 5
    basin_refinements: int = 2
    final_refinements: int = 9
    refinement_points: int = 9
    name: str = "multi-basin-grid"

    def optimize(self, objective: Objective, dimension: int, budget: int) -> OptimizationResult:
        evaluator = BudgetedEvaluator(objective, budget)
        current = np.zeros(dimension)
        evaluator.evaluate(current)

        for axis in range(dimension):
            if evaluator.remaining <= 0:
                break
            current = self._optimize_axis(evaluator, current, axis)
            if evaluator.best_x is not None:
                current = evaluator.best_x.copy()

        return evaluator.result(self.name, dimension)

    def _optimize_axis(self, evaluator: BudgetedEvaluator, current: np.ndarray, axis: int) -> np.ndarray:
        def evaluate_at(value: float) -> float:
            candidate = current.copy()
            candidate[axis] = value
            return evaluator.evaluate(candidate)

        coarse_count = min(max(3, self.coarse_points), evaluator.remaining)
        coarse_values = np.linspace(LOWER_BOUND, UPPER_BOUND, coarse_count)
        scored_values: list[tuple[float, float]] = []
        for value in coarse_values:
            if evaluator.remaining <= 0:
                break
            scored_values.append((evaluate_at(float(value)), float(value)))

        coarse_step = 10.0 / max(1, coarse_count - 1)
        centers: list[float] = []
        for _, value in sorted(scored_values):
            if all(abs(value - center) > 1.5 * coarse_step for center in centers):
                centers.append(value)
            if len(centers) >= self.basins:
                break

        basin_results: list[tuple[float, float, float]] = []
        for center in centers:
            best_value = center
            best_score = float("inf")
            width = coarse_step
            for _ in range(self.basin_refinements):
                if evaluator.remaining <= 0:
                    break
                values = self._window_values(best_value, width, evaluator.remaining)
                for value in values:
                    if evaluator.remaining <= 0:
                        break
                    score = evaluate_at(float(value))
                    if score < best_score:
                        best_score = score
                        best_value = float(value)
                width = self._next_width(values)
            basin_results.append((best_score, best_value, width))

        if basin_results:
            _, best_value, width = min(basin_results)
        else:
            best_value = float(current[axis])
            width = coarse_step

        best_score = evaluator.best_y
        for _ in range(self.final_refinements):
            if evaluator.remaining <= 0:
                break
            values = self._window_values(best_value, width, evaluator.remaining)
            for value in values:
                if evaluator.remaining <= 0:
                    break
                score = evaluate_at(float(value))
                if score < best_score:
                    best_score = score
                    best_value = float(value)
            width = self._next_width(values)

        updated = current.copy()
        updated[axis] = best_value
        return updated

    def _window_values(self, center: float, width: float, remaining: int) -> np.ndarray:
        count = min(max(3, self.refinement_points), remaining)
        low = max(LOWER_BOUND, center - width)
        high = min(UPPER_BOUND, center + width)
        return np.linspace(low, high, count)

    @staticmethod
    def _next_width(values: np.ndarray) -> float:
        if values.size <= 1:
            return 1e-12
        return max(float(values[-1] - values[0]) / max(1, values.size - 1), 1e-12)


@dataclass
class BrentBasinSearch:
    coarse_points: int = 33
    basins: int = 3
    brent_iterations: int = 18
    xatol: float = 1e-8
    name: str = "brent-basin"

    def optimize(self, objective: Objective, dimension: int, budget: int) -> OptimizationResult:
        evaluator = BudgetedEvaluator(objective, budget)
        current = np.zeros(dimension)
        evaluator.evaluate(current)

        for axis in range(dimension):
            if evaluator.remaining <= 0:
                break
            current = self._optimize_axis(evaluator, current, axis)
            if evaluator.best_x is not None:
                current = evaluator.best_x.copy()

        return evaluator.result(self.name, dimension)

    def _optimize_axis(self, evaluator: BudgetedEvaluator, current: np.ndarray, axis: int) -> np.ndarray:
        def evaluate_at(value: float) -> float:
            candidate = current.copy()
            candidate[axis] = value
            return evaluator.evaluate(candidate)

        coarse_count = min(max(5, self.coarse_points), evaluator.remaining)
        coarse_values = np.linspace(LOWER_BOUND, UPPER_BOUND, coarse_count)
        scored_values: list[tuple[float, float]] = []
        for value in coarse_values:
            if evaluator.remaining <= 0:
                break
            scored_values.append((evaluate_at(float(value)), float(value)))

        if len(scored_values) < 3:
            updated = current.copy()
            updated[axis] = min(scored_values)[1] if scored_values else float(current[axis])
            return updated

        coarse_step = 10.0 / max(1, coarse_count - 1)
        centers = self._candidate_centers(scored_values, coarse_step)
        basin_results: list[tuple[float, float]] = []
        for center in centers:
            if evaluator.remaining <= 0:
                break
            low = max(LOWER_BOUND, center - coarse_step)
            high = min(UPPER_BOUND, center + coarse_step)
            best_value, best_score = self._brent_minimize(evaluate_at, low, high, evaluator)
            basin_results.append((best_score, best_value))

        if basin_results:
            _, best_value = min(basin_results)
        else:
            _, best_value = min(scored_values)

        updated = current.copy()
        updated[axis] = best_value
        return updated

    def _candidate_centers(self, scored_values: list[tuple[float, float]], coarse_step: float) -> list[float]:
        centers: list[float] = []
        for _, value in sorted(scored_values):
            if all(abs(value - center) > 1.5 * coarse_step for center in centers):
                centers.append(value)
            if len(centers) >= self.basins:
                break
        return centers

    def _brent_minimize(
        self,
        function,
        low: float,
        high: float,
        evaluator: BudgetedEvaluator,
    ) -> tuple[float, float]:
        if high <= low or evaluator.remaining <= 0:
            value = 0.5 * (low + high)
            return value, float("inf")

        golden = 0.3819660112501051
        a = float(low)
        b = float(high)
        x = w = v = 0.5 * (a + b)
        fx = fw = fv = function(x)
        d = e = 0.0

        for _ in range(self.brent_iterations):
            if evaluator.remaining <= 0:
                break
            midpoint = 0.5 * (a + b)
            tol1 = self.xatol * abs(x) + 1e-12
            tol2 = 2.0 * tol1
            if abs(x - midpoint) <= tol2 - 0.5 * (b - a):
                break

            if abs(e) > tol1:
                r = (x - w) * (fx - fv)
                q = (x - v) * (fx - fw)
                p = (x - v) * q - (x - w) * r
                q = 2.0 * (q - r)
                if q > 0.0:
                    p = -p
                q = abs(q)
                previous_e = e
                e = d
                if (
                    q > 0.0
                    and abs(p) < abs(0.5 * q * previous_e)
                    and p > q * (a - x)
                    and p < q * (b - x)
                ):
                    d = p / q
                    u = x + d
                    if u - a < tol2 or b - u < tol2:
                        d = tol1 if midpoint >= x else -tol1
                else:
                    e = a - x if x >= midpoint else b - x
                    d = golden * e
            else:
                e = a - x if x >= midpoint else b - x
                d = golden * e

            step = d if abs(d) >= tol1 else (tol1 if d > 0.0 else -tol1)
            u = float(np.clip(x + step, a, b))
            fu = function(u)

            if fu <= fx:
                if u >= x:
                    a = x
                else:
                    b = x
                v, w, x = w, x, u
                fv, fw, fx = fw, fx, fu
            else:
                if u < x:
                    a = u
                else:
                    b = u
                if fu <= fw or w == x:
                    v, w = w, u
                    fv, fw = fw, fu
                elif fu <= fv or v == x or v == w:
                    v = u
                    fv = fu

        return float(x), float(fx)


@dataclass
class ModelFitRastriginSearch:
    sample_points: int = 4
    shift_grid_points: int = 2001
    ambiguity_residual_threshold: float = 0.2
    ambiguity_shift_gap: float = 0.01
    ambiguity_sample_value: float = 0.0
    name: str = "model-fit-rastrigin"

    def optimize(self, objective: Objective, dimension: int, budget: int) -> OptimizationResult:
        evaluator = BudgetedEvaluator(objective, budget)
        current = np.zeros(dimension)

        for axis in range(dimension):
            if evaluator.remaining <= 1:
                break
            current = self._fit_axis(evaluator, current, axis, dimension)

        if evaluator.remaining > 0:
            evaluator.evaluate(current)

        return evaluator.result(self.name, dimension)

    def _fit_axis(
        self,
        evaluator: BudgetedEvaluator,
        current: np.ndarray,
        axis: int,
        dimension: int,
    ) -> np.ndarray:
        count = min(max(2, self.sample_points), max(1, evaluator.remaining - 1))
        sample_values = self._sample_values(count)
        observed: list[float] = []

        for value in sample_values:
            if evaluator.remaining <= 1:
                break
            candidate = current.copy()
            candidate[axis] = float(value)
            observed.append(evaluator.evaluate(candidate))

        if len(observed) < 2:
            return current

        samples = np.asarray(sample_values[: len(observed)], dtype=float)
        values = np.asarray(observed, dtype=float)
        best_shift, is_ambiguous = self._fit_shift_with_diagnostics(samples, values, axis, dimension)

        if (
            is_ambiguous
            and len(observed) == 4
            and evaluator.remaining > 1
            and not np.any(np.isclose(samples, self.ambiguity_sample_value))
        ):
            candidate = current.copy()
            candidate[axis] = float(self.ambiguity_sample_value)
            values = np.append(values, evaluator.evaluate(candidate))
            samples = np.append(samples, float(self.ambiguity_sample_value))
            best_shift, _ = self._fit_shift_with_diagnostics(samples, values, axis, dimension)

        updated = current.copy()
        updated[axis] = float(np.clip(best_shift, LOWER_BOUND, UPPER_BOUND))
        return updated

    def _sample_values(self, count: int) -> np.ndarray:
        grid = np.linspace(LOWER_BOUND, UPPER_BOUND, count)
        if count >= 7:
            # Avoid a purely periodic alignment with Rastrigin's local minima.
            offset = 0.173 * (grid[1] - grid[0])
            grid[1::2] = np.clip(grid[1::2] + offset, LOWER_BOUND, UPPER_BOUND)
        return grid

    def _fit_shift(self, samples: np.ndarray, values: np.ndarray, axis: int, dimension: int) -> float:
        best_shift, _ = self._fit_shift_with_diagnostics(samples, values, axis, dimension)
        return best_shift

    def _fit_shift_with_diagnostics(
        self,
        samples: np.ndarray,
        values: np.ndarray,
        axis: int,
        dimension: int,
    ) -> tuple[float, bool]:
        shifts = np.linspace(LOWER_BOUND, UPPER_BOUND, self.shift_grid_points)
        residuals = self._residuals_for_shifts(shifts, samples, values, axis, dimension)
        order = np.argsort(residuals)
        best_index = int(order[0])
        best_shift = float(shifts[best_index])
        is_ambiguous = False

        if order.size > 1:
            second_index = int(order[1])
            shift_gap = abs(float(shifts[best_index] - shifts[second_index]))
            is_ambiguous = (
                float(residuals[best_index]) > self.ambiguity_residual_threshold
                and shift_gap > self.ambiguity_shift_gap
            )

        if 0 < best_index < shifts.size - 1:
            low = float(shifts[best_index - 1])
            high = float(shifts[best_index + 1])
            best_shift = self._golden_minimize_residual(low, high, samples, values, axis, dimension)

        return best_shift, is_ambiguous

    def _golden_minimize_residual(
        self,
        low: float,
        high: float,
        samples: np.ndarray,
        values: np.ndarray,
        axis: int,
        dimension: int,
    ) -> float:
        inv_phi = 0.6180339887498949
        inv_phi_sq = 0.3819660112501051
        a = low
        b = high
        h = b - a
        if h <= 1e-14:
            return 0.5 * (a + b)

        c = a + inv_phi_sq * h
        d = a + inv_phi * h
        yc = self._residual(c, samples, values, axis, dimension)
        yd = self._residual(d, samples, values, axis, dimension)
        for _ in range(32):
            if abs(b - a) <= 1e-12:
                break
            if yc < yd:
                b = d
                d = c
                yd = yc
                h = inv_phi * h
                c = a + inv_phi_sq * h
                yc = self._residual(c, samples, values, axis, dimension)
            else:
                a = c
                c = d
                yc = yd
                h = inv_phi * h
                d = a + inv_phi * h
                yd = self._residual(d, samples, values, axis, dimension)
        return 0.5 * (a + b)

    def _residuals_for_shifts(
        self,
        shifts: np.ndarray,
        samples: np.ndarray,
        values: np.ndarray,
        axis: int,
        dimension: int,
    ) -> np.ndarray:
        raw = samples[None, :] - shifts[:, None]
        modeled = self._coco_rastrigin_component(raw, axis, dimension)
        offsets = np.mean(values[None, :] - modeled, axis=1)
        errors = modeled + offsets[:, None] - values[None, :]
        return np.mean(errors * errors, axis=1)

    def _residual(
        self,
        shift: float,
        samples: np.ndarray,
        values: np.ndarray,
        axis: int,
        dimension: int,
    ) -> float:
        modeled = self._coco_rastrigin_component(samples - shift, axis, dimension)
        offset = float(np.mean(values - modeled))
        errors = modeled + offset - values
        return float(np.mean(errors * errors))

    @staticmethod
    def _coco_rastrigin_component(raw: np.ndarray, axis: int, dimension: int) -> np.ndarray:
        z = ModelFitRastriginSearch._tosz(np.asarray(raw, dtype=float))
        if dimension > 1:
            beta_axis = 0.2 * axis / (dimension - 1)
            positive = z > 0.0
            z = z.copy()
            z[positive] = z[positive] ** (1.0 + beta_axis * np.sqrt(z[positive]))
            scale = 10.0 ** (0.5 * axis / (dimension - 1))
        else:
            scale = 1.0
        z = scale * z
        return 10.0 * (1.0 - np.cos(2.0 * np.pi * z)) + z * z

    @staticmethod
    def _tosz(values: np.ndarray) -> np.ndarray:
        x = np.asarray(values, dtype=float)
        result = np.zeros_like(x, dtype=float)
        nonzero = x != 0.0
        if not np.any(nonzero):
            return result

        selected = x[nonzero]
        logs = np.log(np.abs(selected))
        c1 = np.where(selected > 0.0, 10.0, 5.5)
        c2 = np.where(selected > 0.0, 7.9, 3.1)
        result[nonzero] = np.sign(selected) * np.exp(
            logs + 0.049 * (np.sin(c1 * logs) + np.sin(c2 * logs))
        )
        return result


def run_optimizer(
    optimizer: Optimizer,
    objective: Objective,
    dimension: int,
    budget: int,
) -> OptimizationResult:
    if budget <= 0:
        raise ValueError("budget must be positive")
    return optimizer.optimize(objective=objective, dimension=dimension, budget=budget)
