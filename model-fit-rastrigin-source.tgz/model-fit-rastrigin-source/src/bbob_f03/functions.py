from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def shifted_rastrigin(x: np.ndarray, shift: np.ndarray) -> float:
    """Evaluate separable Rastrigin with global minimum at ``shift``."""

    z = np.asarray(x, dtype=float) - np.asarray(shift, dtype=float)
    return float(10.0 * z.size + np.sum(z * z - 10.0 * np.cos(2.0 * np.pi * z)))


@dataclass
class Rastrigin:
    shift: np.ndarray
    evaluations: int = 0

    def __post_init__(self) -> None:
        self.shift = np.asarray(self.shift, dtype=float)

    @property
    def dimension(self) -> int:
        return int(self.shift.size)

    def __call__(self, x: np.ndarray) -> float:
        self.evaluations += 1
        return shifted_rastrigin(np.asarray(x, dtype=float), self.shift)
