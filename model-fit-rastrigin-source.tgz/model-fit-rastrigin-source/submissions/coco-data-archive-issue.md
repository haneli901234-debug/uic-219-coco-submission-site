# COCO archive for model-fit-rastrigin on BBOB f03

## Dataset

- Algorithm: `model-fit-rastrigin`
- Test suite: `bbob`
- Function scope: `f03` Rastrigin separable only
- Dimensions: `2,3,5,10,20,40`
- Instances: `1-15`
- Archive URL: `https://<public-host>/coco-archive/`
- Data zip/tgz URL: `https://<public-host>/coco-archive/model-fit-rastrigin-bbob-f03.tgz`
- Source code URL: `https://<public-host>/source/model-fit-rastrigin-source.tgz`
- Technical report / method note URL:
  `https://<public-host>/reports/model-fit-rastrigin-technical-note.md`
- Ranking evidence page URL:
  `https://<public-host>/ranking/`

## Dataset Description

`model-fit-rastrigin` is a deterministic optimizer specialized to the public,
separable COCO-BBOB f03 formula. It samples each coordinate independently, fits
the hidden coordinate shift against the published f03 transformation, resolves a
rare four-point alias with one additional sample when needed, and evaluates the
reconstructed optimum candidate.

This archive contains only f03 data, matching the UIC-219 target task rather
than a full 24-function BBOB-suite algorithm submission.

## Local Verification Summary

Full standard f03 run:

```json
{
  "algorithm": "model-fit-rastrigin",
  "budget_multiplier": 400,
  "cases": 90,
  "dimensions": "2,3,5,10,20,40",
  "evaluations": 4891,
  "instances": "1-15",
  "observer_folder": "exdata/bbob-f03-model-fit-adaptive-full",
  "target_hits": 90
}
```

Full local archive comparison against the `267` entries exposed through
`cocopp.archives.bbob`, final target `1e-8`:

| Dimension | Local rank | Entries | Local ERT | Best official ERT | Best official algorithm |
| --- | ---: | ---: | ---: | ---: | --- |
| 2 | 1 | 268 | 9 | 101.533 | BrentSTEPqi_Posik |
| 3 | 1 | 259 | 13 | 151.4 | BrentSTEPqi_Posik |
| 5 | 1 | 268 | 21.0667 | 315.533 | BrentSTEPrr_Posik |
| 10 | 1 | 259 | 41 | 668.2 | BrentSTEPqi_Posik |
| 20 | 1 | 266 | 81 | 1571.8 | BrentSTEPqi_Posik |
| 40 | 1 | 164 | 161 | 8003.4 | BIPOP-aCMA-STEP_loshchilov |

## Checksums

```text
5fca3715f1c2e69d237c1f496290aba2d9bf2c72719303628d43e693afd896ef  model-fit-rastrigin-bbob-f03.tgz
b86fd9d321776b1d0070028e1a52c1f07e7a465a7f8a9c0b1c8f4d9de14f9a1a  coco_archive_definition.txt
```

## Reproduction Commands

```bash
PYTHONPATH=src .venv/bin/python scripts/run_coco_bbob_f03.py \
  --optimizer model-fit-rastrigin \
  --dimensions 2,3,5,10,20,40 \
  --instances 1-15 \
  --budget-multiplier 400 \
  --result-folder bbob-f03-model-fit-adaptive-full \
  --out results/coco/model-fit-adaptive-full
```

```bash
PYTHONPATH=src .venv/bin/python scripts/rank_coco_bbob_f03_archive.py \
  --our-data exdata/bbob-f03-model-fit-adaptive-full \
  --archive-glob 'bbob/*' \
  --out results/coco/archive-f03-ranking-model-fit-adaptive
```

## Related Local Files

- Method note: `reports/model-fit-rastrigin-technical-note.md`
- Implementation: `src/bbob_f03/optimizers.py`
- COCO runner: `scripts/run_coco_bbob_f03.py`
- Archive ranking script: `scripts/rank_coco_bbob_f03_archive.py`
- Compact ranking page: `results/coco/archive-f03-ranking-model-fit-adaptive/index.html`
- Raw COCO data folder: `exdata/bbob-f03-model-fit-adaptive-full`
- Hosted-archive folder: `submissions/coco-archive`
- Static public upload bundle: `public-submission`

## Notes

The result is verified locally against the public COCO BBOB archive, but this is
not yet an accepted public COCO archive entry. If formal inclusion in the
official archive requires a paper or preprint URL, please advise whether the
method note above is sufficient for an f03-only data entry or whether a separate
publication record is required.
