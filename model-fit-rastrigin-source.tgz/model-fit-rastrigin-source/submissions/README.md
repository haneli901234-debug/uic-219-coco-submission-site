# UIC-219 COCO Submission Packet

This directory contains the submission packet for the `UIC-219` optimized
COCO-BBOB f03 run.

## Files

- `model-fit-rastrigin-bbob-f03.tgz`: raw COCO observer output for
  `model-fit-rastrigin` on BBOB f03, dimensions `2,3,5,10,20,40`, instances
  `1-15`.
- `coco-archive/`: clean local COCO archive folder containing the same `.tgz`
  plus `coco_archive_definition.txt`.
- `coco-data-archive-issue.md`: ready-to-edit GitHub issue body for
  `numbbo/data-archive`.
- `../results/coco/archive-f03-ranking-model-fit-adaptive/index.html`: local ranking
  webpage showing the submitted run against the official BBOB archive.
- `../public-submission/`: single static directory ready to upload to a public
  host, containing the archive, ranking page, report, source snapshot, and
  checksums.
- `../reports/model-fit-rastrigin-technical-note.md`: local technical report
  draft to publish with the source repository or convert into a preprint.

## Checksums

```text
5fca3715f1c2e69d237c1f496290aba2d9bf2c72719303628d43e693afd896ef  model-fit-rastrigin-bbob-f03.tgz
b86fd9d321776b1d0070028e1a52c1f07e7a465a7f8a9c0b1c8f4d9de14f9a1a  coco-archive/coco_archive_definition.txt
```

## Local Validation

```bash
XDG_CACHE_HOME="$PWD/.cache" MPLCONFIGDIR="$PWD/.cache/matplotlib" \
PYTHONPATH=src .venv/bin/python -c "import cocopp; arch=cocopp.archiving.get('submissions/coco-archive'); print(list(arch)); print(arch.get('model-fit', remote=False))"
```

Expected output:

```text
['model-fit-rastrigin-bbob-f03.tgz']
/Users/eli/Documents/optimize/submissions/coco-archive/model-fit-rastrigin-bbob-f03.tgz
```

## Public Submission Steps

1. Rebuild the static bundle with
   `PYTHONPATH=src .venv/bin/python scripts/build_public_submission_bundle.py`.
2. Upload the entire `public-submission/` folder to a public URL.
3. Confirm `https://<public-host>/coco-archive/coco_archive_definition.txt`
   and `https://<public-host>/coco-archive/model-fit-rastrigin-bbob-f03.tgz`
   are directly downloadable.
4. Confirm `https://<public-host>/ranking/` opens the rank-1 evidence page.
5. Render and validate the final issue body:

   ```bash
   PYTHONPATH=src .venv/bin/python scripts/finalize_coco_submission.py \
     --public-base-url https://<public-host> \
     --validate-remote \
     --validate-cocopp
   ```

6. Open an issue at `https://github.com/numbbo/data-archive/issues` with
   `submissions/coco-data-archive-issue-final.md`.

Official COCO archive inclusion usually expects a publication or preprint.
Without that, submit as a hosted COCO archive announcement rather than a
formal inclusion request.
