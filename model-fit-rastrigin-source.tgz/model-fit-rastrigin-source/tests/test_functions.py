import unittest

import numpy as np

from bbob_f03.functions import Rastrigin, shifted_rastrigin


class RastriginTests(unittest.TestCase):
    def test_origin_is_global_minimum_for_unshifted_function(self):
        value = shifted_rastrigin(np.zeros(4), np.zeros(4))

        self.assertAlmostEqual(value, 0.0, places=12)

    def test_shifted_optimum_has_zero_value_at_shift(self):
        shift = np.array([1.25, -0.5, 2.0])
        objective = Rastrigin(shift=shift)

        self.assertAlmostEqual(objective(shift), 0.0, places=12)

    def test_evaluation_count_increments_once_per_call(self):
        objective = Rastrigin(shift=np.zeros(2))

        objective(np.array([1.0, 0.0]))
        objective(np.array([0.0, 1.0]))

        self.assertEqual(objective.evaluations, 2)


if __name__ == "__main__":
    unittest.main()
