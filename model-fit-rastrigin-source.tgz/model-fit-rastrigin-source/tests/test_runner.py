import unittest

from bbob_f03.optimizers import CoordinateSnapSearch
from bbob_f03.runner import BenchmarkCase, aggregate_rows, run_local_cases


class RunnerTests(unittest.TestCase):
    def test_seeded_local_cases_are_deterministic(self):
        cases = [
            BenchmarkCase(dimension=2, budget=40, seed=101),
            BenchmarkCase(dimension=3, budget=60, seed=102),
        ]
        optimizer = CoordinateSnapSearch(seed=11, starts=2)

        first = run_local_cases(optimizer, cases)
        second = run_local_cases(optimizer, cases)

        self.assertEqual(first, second)

    def test_summary_counts_target_hits_and_budget(self):
        rows = [
            {"best_y": 1e-10, "evaluations": 30},
            {"best_y": 1.5, "evaluations": 40},
        ]

        summary = aggregate_rows(rows, target=1e-8)

        self.assertEqual(summary["cases"], 2)
        self.assertEqual(summary["target_hits"], 1)
        self.assertEqual(summary["evaluations"], 70)


if __name__ == "__main__":
    unittest.main()
