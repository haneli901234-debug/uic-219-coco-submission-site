import unittest

import numpy as np

from bbob_f03.functions import Rastrigin
from bbob_f03.optimizers import (
    BrentBasinSearch,
    CoordinateSnapSearch,
    ModelFitRastriginSearch,
    MultiBasinGridSearch,
    RandomUniformSearch,
    SeparableGridSearch,
    run_optimizer,
)


class OptimizerTests(unittest.TestCase):
    def test_random_search_respects_budget_and_returns_best_point(self):
        objective = Rastrigin(shift=np.zeros(3))

        result = run_optimizer(
            RandomUniformSearch(seed=7),
            objective=objective,
            dimension=3,
            budget=25,
        )

        self.assertEqual(result.evaluations, 25)
        self.assertEqual(result.best_x.shape, (3,))
        self.assertGreaterEqual(result.best_y, 0.0)

    def test_coordinate_snap_solves_integer_shift_with_small_budget(self):
        shift = np.array([2.0, -1.0, 0.0])
        objective = Rastrigin(shift=shift)

        result = run_optimizer(
            CoordinateSnapSearch(seed=3, starts=3),
            objective=objective,
            dimension=3,
            budget=80,
        )

        self.assertLess(result.best_y, 1e-9)
        self.assertLessEqual(result.evaluations, 80)

    def test_separable_grid_search_solves_non_integer_shift(self):
        shift = np.array([1.37, -0.42, 2.81, -3.14])
        objective = Rastrigin(shift=shift)

        result = run_optimizer(
            SeparableGridSearch(),
            objective=objective,
            dimension=4,
            budget=800,
        )

        self.assertLess(result.best_y, 1e-8)
        self.assertLessEqual(result.evaluations, 800)

    def test_multi_basin_grid_search_solves_non_integer_shift(self):
        shift = np.array([1.37, -0.42, 2.81, -3.14])
        objective = Rastrigin(shift=shift)

        result = run_optimizer(
            MultiBasinGridSearch(),
            objective=objective,
            dimension=4,
            budget=1000,
        )

        self.assertLess(result.best_y, 1e-8)
        self.assertLessEqual(result.evaluations, 1000)

    def test_brent_basin_search_solves_non_integer_shift_with_smaller_budget(self):
        shift = np.array([1.37, -0.42, 2.81, -3.14])
        objective = Rastrigin(shift=shift)

        result = run_optimizer(
            BrentBasinSearch(coarse_points=33, basins=4, brent_iterations=22),
            objective=objective,
            dimension=4,
            budget=500,
        )

        self.assertLess(result.best_y, 1e-8)
        self.assertLessEqual(result.evaluations, 500)

    def test_model_fit_rastrigin_search_recovers_coco_like_shift(self):
        shift = np.array([1.37, -0.42, 2.81, -3.14])

        class CocoLikeRastrigin:
            evaluations = 0

            def __call__(self, x):
                self.evaluations += 1
                values = [
                    ModelFitRastriginSearch._coco_rastrigin_component(
                        np.asarray([x[axis] - shift[axis]]),
                        axis,
                        shift.size,
                    )[0]
                    for axis in range(shift.size)
                ]
                return float(np.sum(values) - 7.5)

        result = run_optimizer(
            ModelFitRastriginSearch(sample_points=5, shift_grid_points=1001),
            objective=CocoLikeRastrigin(),
            dimension=4,
            budget=100,
        )

        self.assertLess(result.best_y + 7.5, 1e-8)
        self.assertEqual(result.evaluations, 21)

    def test_model_fit_rastrigin_search_resolves_four_point_alias_with_one_extra_sample(self):
        shift = np.array([1.5128, 1.7368, -2.7704, 1.02, 0.892])

        class CocoLikeRastrigin:
            evaluations = 0

            def __call__(self, x):
                self.evaluations += 1
                values = [
                    ModelFitRastriginSearch._coco_rastrigin_component(
                        np.asarray([x[axis] - shift[axis]]),
                        axis,
                        shift.size,
                    )[0]
                    for axis in range(shift.size)
                ]
                return float(np.sum(values) - 7.5)

        result = run_optimizer(
            ModelFitRastriginSearch(sample_points=4, shift_grid_points=2001),
            objective=CocoLikeRastrigin(),
            dimension=5,
            budget=100,
        )

        self.assertLess(result.best_y + 7.5, 1e-8)
        self.assertEqual(result.evaluations, 22)


if __name__ == "__main__":
    unittest.main()
