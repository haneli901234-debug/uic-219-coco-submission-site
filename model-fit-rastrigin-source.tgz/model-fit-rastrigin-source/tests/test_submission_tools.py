from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from scripts import finalize_coco_submission as finalize


class SubmissionToolTests(unittest.TestCase):
    def test_normalize_base_url_strips_query_fragment_and_trailing_slash(self) -> None:
        self.assertEqual(
            finalize.normalize_base_url("https://example.com/uic219/?utm=1#top"),
            "https://example.com/uic219",
        )

    def test_normalize_base_url_requires_http_host(self) -> None:
        with self.assertRaises(ValueError):
            finalize.normalize_base_url("file:///tmp/public-submission")

    def test_render_issue_replaces_public_host_placeholders(self) -> None:
        template = "Archive: https://<public-host>/coco-archive/\nRanking: https://<public-host>/ranking/\n"
        rendered = finalize.render_issue(template, "https://example.com/uic219")
        self.assertIn("https://example.com/uic219/coco-archive/", rendered)
        self.assertIn("https://example.com/uic219/ranking/", rendered)

    def test_validate_local_bundle_reports_checksum_mismatch(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "file.txt").write_text("changed", encoding="utf-8")
            (root / "checksums.sha256").write_text(
                "0000000000000000000000000000000000000000000000000000000000000000  file.txt\n",
                encoding="utf-8",
            )
            errors = finalize.validate_local_bundle(root)
        self.assertTrue(any("checksum mismatch" in error for error in errors))


if __name__ == "__main__":
    unittest.main()
